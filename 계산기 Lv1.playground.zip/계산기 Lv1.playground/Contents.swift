struct Coffee {
    var name: String?
    var size: String?
    
    func brewCoffee() -> String {
        if let name = self.name {
            return "\(name) ☕️ 한 잔 나왔습니다."
        } else {
            return "오늘의 커피 ☕️ 한 잔 나왔습니다."
        }
    }
}

let americano = Coffee(name: "카페라떼")
